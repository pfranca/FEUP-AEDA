var searchData=
[
  ['removecliente',['removeCliente',['../class_firma.html#aacab7d264991c337d050b34c3c780149',1,'Firma']]],
  ['resetpontos',['resetPontos',['../class_cliente.html#ae0ec47e10d945635d7675af04a44c2dc',1,'Cliente']]]
];
