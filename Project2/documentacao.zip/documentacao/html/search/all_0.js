var searchData=
[
  ['adicionacliente',['adicionaCliente',['../class_firma.html#ae9dd1cd7b788ed1a2dcc8b3220fe3f7b',1,'Firma']]],
  ['adicionaservico',['adicionaServico',['../class_cliente.html#ad0a60df2b4b193bfc32ed13b50bdeb72',1,'Cliente']]],
  ['alteranome',['alteraNome',['../class_firma.html#aa61dea4f9e14f3560016b4e5e23e1978',1,'Firma']]],
  ['alterarmorada',['alterarMorada',['../class_firma.html#ac0b6e0dcb4f4a2231e5b2828abaaa662',1,'Firma']]]
];
