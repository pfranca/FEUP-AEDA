var searchData=
[
  ['servico',['Servico',['../class_servico.html',1,'Servico'],['../class_servico.html#a35a8871adce675461c6a37919351f39c',1,'Servico::Servico()']]],
  ['sethistorico',['sethistorico',['../class_cliente.html#a17bbd7ca8ac7319a422ec4962225b101',1,'Cliente']]],
  ['setmorada',['setMorada',['../class_cliente.html#acc609f89f747216e1f5db4877f44dfb1',1,'Cliente']]],
  ['setnome',['setNome',['../class_cliente.html#a383af20fa7ace06d4f04fe26e82e0ca2',1,'Cliente']]],
  ['setpago',['setPago',['../class_servico.html#ad51a5b61535715cd6ab8419898fcffce',1,'Servico']]],
  ['setpontos',['setPontos',['../class_cliente.html#a181651eccd4dc8b0603dd4ee387d2bff',1,'Cliente']]]
];
