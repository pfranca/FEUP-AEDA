var searchData=
[
  ['cliente',['Cliente',['../class_cliente.html#ab6a372f412692c12c4be4427b00a3f6e',1,'Cliente::Cliente()'],['../class_cliente.html#a1f279e2258a73d1d2b89ca606aa6c63d',1,'Cliente::Cliente(string nome, string morada, const int nif)']]],
  ['clienteempresarial',['ClienteEmpresarial',['../class_cliente_empresarial.html#a000483340f209b3548920539ae09df55',1,'ClienteEmpresarial']]],
  ['clienteparticular',['ClienteParticular',['../class_cliente_particular.html#a5dd6aca3a564faa699ab4e6288779417',1,'ClienteParticular']]]
];
